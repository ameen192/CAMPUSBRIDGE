from django.apps import AppConfig


class RecoveryConfig(AppConfig):
    name = 'recovery'
